var usrename="akhil@gmail.com";
console.log(usrename);
//-----------------------------------------
// local variable:-A variable which is created inside a function
function f1(){
    var a =100;
    var b =200;
    console.log(a);
    console.log(b);
}
f1();

//global variable: A variable which is creat3ed outside a function,it can be accessed through out the file
var usrename="akhil"
var age=24;
console.log(usrename);
console.log(age);
function f1(){
    console.log(usrename);
    age=23;
    console.log(age);
}
f1();
age=90;
console.log(age);

//Note:- JS is called weakly typed language for the following reason,

var a=10;
console.log(a);
console.log(typeof a);
a="hello";
console.log(a);
console.log(typeof a);
