//Arrays

//An array is a linear data structure used to organize data in a proper format.

var users=["ram","kiran","ravi"];
console.log(users[0]);
users[3]="raj";
console.log(users[3]);
console.log(users);
users[0]=20;
console.log(users);



var users=["user1","user2","user3"];
users.push("user4");
users.push("user5");
users.push("user1");
users.unshift("user9");
console.log(users);
var x=users.indexOf("user2");
console.log(x);
users.splice(x,1);
console.log(users);