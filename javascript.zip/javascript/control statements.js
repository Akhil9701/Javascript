//CONTROL STATEMENTS

//If statement
var isDone=false;
if(isDone==true){
    console.log("leave for the day");
}

//if-else>>

var isDone=false;
if(isDone){
    console.log("Leave for the day");
  }
 else
 {
    console.log("continue working!!");
 }

 
//switch:  
//if we have multiple choices, we use switch statement to select one choice.

var country="india";
switch(country){
    case "india":console.log("rupee/INR");break;
    case "uae":console.log("diram");break;
    case "usa":console.log("dollar");break;
    default:console.log("wrong choice");
}

//while loop

var num1=1;
var num2=20;
while(num1<=num2){
    console.log(num1);
    num1++;

}

//do while
var num1=1;num2=5;

while(num1>num2){
 console.log(num1);
 num1++;
}  // not print anything

do{
 console.log(num1);//1>>prints
 num1++;//2
}
while(num1>num2);
console.log("end of the program");

//for loop
for(var num1=1;num1<5;num1++){
    console.log(num1);
 }
 var num1=1
for(;;){
   console.log(num1);
   num1++;
}