//Operators
var a=10;
var b=20;
var c=30;

console.log(a<b && a<c);
console.log(a>b && a<c);
console.log(a>b || a<c);

//Type Operators:
//1.typeof: for primtivies
//2.instanceof:  for objects

var a=10;
console.log(typeof a =="number")
var x={};
console.log(x instanceof Object);
console.log(a instanceof Object);
