// Function Scopes

function f1(){
    var a=10;//local variable
    console.log(a);
    function f2(){//inner function or nested function
        return 100;
    }
}