//Variables are the identifiers used to represent some data in the application.
//syntax:
// var var_name=value;
var username="ak@gmail.com"
console.log(username);


/////  Data Types///////////
// 1.boolean:used to represent true or false

var isDone=false;
console.log(isDone);
console.log(typeof isDone);

// 2.Number
var age=20;
console.log(age);
console.log(typeof age);


// 3.String
//used to store single charecter or set of charecters
 var emailId="ak@gmail.com";
 var s='a';
 console.log(emailId);
 console.log(typeof s)


// 4.Array
// Used to store set of values in a single variable
var users=["ram","ravi","kiran","abc"];
// note: Arrays in JS are unique compared to other lang.

var userData=["ram",102,true,["abc",12]];
console.log(users);
console.log(userData);
console.log(users[0]);
console.log(userData[1]);
console.log(users[10]);
users[10]="1000";
console.log(users[10]);
console.log(users);


// 5.Object

var employee={
    name:"Akhil",
    address:"Hyderabad",
    designation:"Junior software Developer",
    getData:function(){
        return this.name + "\n" + this.address + "\n" +this.designation
    }
}
console.log(employee.name);
console.log(employee.address);
console.log(employee.designation);
console.log(employee.getData());
console.log(typeof employee);

